import java.awt.Cursor;
import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;


public class LockingGlassPane extends JComponent {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public LockingGlassPane() {
        setOpaque(false);
        super.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    }
    @Override public void setVisible(boolean isVisible) {
        boolean oldVisible = isVisible();
        super.setVisible(isVisible);
        JRootPane rootPane = SwingUtilities.getRootPane(this);
        if(rootPane!=null && isVisible()!=oldVisible) {
            rootPane.getLayeredPane().setVisible(!isVisible);
        }
    }
    @Override public void paintComponent(Graphics g) {
        JRootPane rootPane = SwingUtilities.getRootPane(this);
        if(rootPane!=null) {
            rootPane.getLayeredPane().print(g);
        }
        super.paintComponent(g);
    }
}
