import javax.swing.JPanel;

import java.awt.Cursor;
import java.awt.Frame;
import javax.swing.JDialog;

import java.awt.Rectangle;
import javax.swing.JLabel;
import java.awt.Font;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;

import twitter4j.TwitterException;
import twitter4j.User;
import java.awt.Color;

public class profilewindow extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JLabel jLabel2 = null;
	private JLabel jLabel3 = null;
	private JLabel jLabel4 = null;
	private JLabel jLabel5 = null;
	private JLabel jLabel6 = null;
	private JLabel jLabel7 = null;
	private JLabel jLabel8 = null;
	private JLabel jLabel9 = null;
	private JTextArea jTextArea = null;
	private JScrollPane jScrollPane = null;
	private JLabel jLabel10 = null;
	private JLabel jLabel11 = null;
	private JLabel jLabel12 = null;
	private JLabel jLabel13 = null;
	private JScrollPane jScrollPane1 = null;
	private JTextArea jTextArea1 = null;
	private JButton jButton = null;
	private JLabel jLabel14 = null;
	private JLabel jLabel15 = null;
	private JLabel jLabel16 = null;
	private JLabel jLabel17 = null;
	private JLabel jLabel18 = null;
	private JLabel jLabel19 = null;
	private JLabel jLabel20 = null;
	private JLabel jLabel21 = null;
	private JLabel jLabel22 = null;
	private JLabel jLabel23 = null;
	private JLabel jLabel24 = null;
	private JLabel jLabel25 = null;
	private JLabel jLabel26 = null;
	private JLabel jLabel27 = null;
	private JLabel jLabel28 = null;
	private User showuser_data = null;  //  @jve:decl-index=0:
	private String from_url;  //  @jve:decl-index=0:
	private Date tweet_date;  //  @jve:decl-index=0:
	private Date make_date;  //  @jve:decl-index=0:
	private static final String DATE_PATTERN = "yyyy'�N'MM'��'dd'��' HH'��'mm'��'ss'�b'";  //  @jve:decl-index=0:

	/**
	 * @param owner
	 */
	public profilewindow(Frame owner) {
		super(owner);
		initialize();
		make_data(mainwindow.show_user);
	}

	@SuppressWarnings("deprecation")
	private void make_data(int showuser) {
		try {
			showuser_data  = mainwindow.twitter.showUser(showuser);
		} catch (TwitterException e) {
			e.printStackTrace();
		}
		if(showuser_data != null){
			//���[�U�[��_14
			jLabel14.setText("@" + showuser_data.getScreenName());
			//�j�b�N�l�[��_15
			jLabel15.setText(showuser_data.getName());
			//ID_16
			jLabel16.setText(String.valueOf(showuser_data.getId()));
			//Web_17
			if(showuser_data.getURL() == null){
				jLabel17.setText("");
			}else{
				jLabel17.setText("<html><u>" + String.valueOf(showuser_data.getURL()) + "</u></html>");
			}
			//���ݒn_18
			jLabel18.setText(showuser_data.getLocation());
			//�A�J�E���g�쐬��_19
			make_date = showuser_data.getCreatedAt();
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN);
			String make_date_ = sdf.format(make_date);
			jLabel19.setText(make_date_);
			//����J_20
			if(showuser_data.isProtected() == true){
				jLabel20.setText("�͂�");
			}else{
				jLabel20.setText("������");
			}
			//�F�؍ς�_21
			if(showuser_data.isVerified() == true){
				jLabel21.setText("�͂�");
			}else{
				jLabel21.setText("������");
			}
			//���ȏЉ�
			jTextArea.append(showuser_data.getDescription());
			jTextArea.setCaretPosition(0);
			//�t�H���[_22
			jLabel22.setText("<html><u>" + String.valueOf(showuser_data.getFriendsCount()) + "</u></html>");
			//�t�H�����[_23
			jLabel23.setText("<html><u>" + String.valueOf(showuser_data.getFollowersCount()) + "</u></html>");
			//�c�C�[�g��_24
			jLabel24.setText("<html><u>" + String.valueOf(showuser_data.getStatusesCount()) + "</u></html>");
			//���C�ɓ���_25
			jLabel25.setText("<html><u>" + String.valueOf(showuser_data.getFavouritesCount()) + "</u></html>");
			//�ŋ߂̃c�C�[�g_����_26
			try{
				tweet_date = showuser_data.getStatusCreatedAt();
				String tweet_date_ = sdf.format(tweet_date);
				jLabel26.setText(tweet_date_);
			}catch(NullPointerException e){
				System.out.println("�ŐV�c�C�[�g�̎����̎擾�Ɏ��s���܂���");
				jLabel26.setText("unknown");
			}
			//�ŋ߂̃c�C�[�g_���e��_27
			try{
				from_url = showuser_data.getStatusSource();
				if(from_url.equalsIgnoreCase("web")){
					from_url = "http://twitter.com";
					jLabel27.setText("<html><u><a href=\"http://twitter.com/\" target=\"_blank\">Web</a></u> ����</html>");
				}else{
					Pattern p1 = Pattern.compile("(http://|https://){1}[\\w\\.\\-/:\\#\\?\\=\\&\\;\\%\\~\\+]+", Pattern.CASE_INSENSITIVE);
					Matcher m1 = p1.matcher(from_url);
					if (m1.find()){
						from_url = m1.group();
					}
					jLabel27.setText("<html><u>" + showuser_data.getStatusSource() + "</u> ����</html>");
				}
			}catch(NullPointerException e){
				System.out.println("�ŐV�c�C�[�g�̓��e���̎擾�Ɏ��s���܂���");
				from_url = "unknown";
				jLabel27.setText(from_url);
			}
			//�ŋ߂̃c�C�[�g
			try{
				jTextArea1.append(showuser_data.getStatus().getText());
			}catch(NullPointerException e){
				System.out.println("�ŐV�c�C�[�g�̓��e���̎擾�Ɏ��s���܂���");
				jTextArea1.append("unknown");
			}
			jTextArea1.setCaretPosition(0);
			//�A�C�R��_28
			String image_url = String.valueOf(showuser_data.getProfileImageURL());
			String change_before = "_normal";
			Pattern p2 = Pattern.compile(change_before);
			Matcher m2 = p2.matcher(image_url);
			image_url = m2.replaceAll("_bigger");
			jLabel28.setText("<html><img src=\"" + image_url + "\">");
		}
		
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(634, 492);
		this.setModal(true);
		this.setTitle("�v���t�B�[��");
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setContentPane(getJContentPane());

	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel28 = new JLabel();
			jLabel28.setBounds(new Rectangle(10, 20, 72, 72));
			jLabel28.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel28.setText("�C���[�W");
			jLabel27 = new JLabel();
			jLabel27.setBounds(new Rectangle(120, 310, 507, 19));
			jLabel27.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel27.setText("�ŋ߂̃c�C�[�g_���e��-27");
			jLabel27.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					if(!from_url.equals("unknown")){
						url_open(from_url);
					}
				}
			});
			jLabel26 = new JLabel();
			jLabel26.setBounds(new Rectangle(120, 290, 507, 19));
			jLabel26.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel26.setText("�ŋ߂̃c�C�[�g_����-26");
			jLabel25 = new JLabel();
			jLabel25.setBounds(new Rectangle(390, 270, 80, 19));
			jLabel25.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel25.setForeground(Color.blue);
			jLabel25.setText("���C�ɓ���-25");
			jLabel25.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					url_open("http://twitter.com/" + showuser_data.getScreenName() + "/favorites");
				}
			});
			jLabel24 = new JLabel();
			jLabel24.setBounds(new Rectangle(90, 270, 80, 19));
			jLabel24.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel24.setForeground(Color.blue);
			jLabel24.setText("�c�C�[�g��-24");
			jLabel24.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					url_open("http://twitter.com/" + showuser_data.getScreenName());
				}
			});
			jLabel23 = new JLabel();
			jLabel23.setBounds(new Rectangle(390, 250, 80, 19));
			jLabel23.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel23.setForeground(Color.blue);
			jLabel23.setText("�t�H�����[-23");
			jLabel23.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					url_open("http://twitter.com/" + showuser_data.getScreenName() + "/followers");
				}
			});
			jLabel22 = new JLabel();
			jLabel22.setBounds(new Rectangle(90, 250, 80, 19));
			jLabel22.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel22.setForeground(Color.blue);
			jLabel22.setText("�t�H���[-22");
			jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					url_open("http://twitter.com/" + showuser_data.getScreenName() + "/following");
				}
			});
			jLabel21 = new JLabel();
			jLabel21.setBounds(new Rectangle(390, 130, 237, 19));
			jLabel21.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel21.setText("�F�؍ς�-21");
			jLabel20 = new JLabel();
			jLabel20.setBounds(new Rectangle(90, 130, 210, 19));
			jLabel20.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel20.setText("����J-20");
			jLabel19 = new JLabel();
			jLabel19.setBounds(new Rectangle(192, 100, 435, 19));
			jLabel19.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel19.setText("�A�J�E���g�쐬��-19");
			jLabel18 = new JLabel();
			jLabel18.setBounds(new Rectangle(192, 80, 435, 19));
			jLabel18.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel18.setText("���ݒn-18");
			jLabel17 = new JLabel();
			jLabel17.setBounds(new Rectangle(192, 60, 435, 19));
			jLabel17.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel17.setForeground(Color.blue);
			jLabel17.setText("Web-17");
			jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					if(jLabel17.getText() != ""){
						url_open(String.valueOf(showuser_data.getURL()));
					}
				}
			});
			jLabel16 = new JLabel();
			jLabel16.setBounds(new Rectangle(538, 40, 89, 19));
			jLabel16.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel16.setText("ID-16");
			jLabel15 = new JLabel();
			jLabel15.setBounds(new Rectangle(192, 40, 313, 19));
			jLabel15.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel15.setText("�j�b�N�l�[��-15");
			jLabel14 = new JLabel();
			jLabel14.setBounds(new Rectangle(192, 20, 435, 19));
			jLabel14.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel14.setText("���[�U�[��-14");
			jLabel13 = new JLabel();
			jLabel13.setBounds(new Rectangle(0, 290, 120, 19));
			jLabel13.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel13.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel13.setText("�ŋ߂̃c�C�[�g�F");
			jLabel12 = new JLabel();
			jLabel12.setBounds(new Rectangle(300, 270, 90, 19));
			jLabel12.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel12.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel12.setText("���C�ɓ���F");
			jLabel11 = new JLabel();
			jLabel11.setBounds(new Rectangle(0, 270, 90, 19));
			jLabel11.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel11.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel11.setText("�c�C�[�g���F");
			jLabel10 = new JLabel();
			jLabel10.setBounds(new Rectangle(300, 250, 90, 19));
			jLabel10.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel10.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel10.setText("�t�H�����[�F");
			jLabel9 = new JLabel();
			jLabel9.setBounds(new Rectangle(0, 250, 90, 19));
			jLabel9.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel9.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel9.setText("�t�H���[�F");
			jLabel8 = new JLabel();
			jLabel8.setBounds(new Rectangle(0, 150, 90, 19));
			jLabel8.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel8.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel8.setText("���ȏЉ�F");
			jLabel7 = new JLabel();
			jLabel7.setBounds(new Rectangle(300, 130, 90, 19));
			jLabel7.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel7.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel7.setText("�F�؍ς݁F");
			jLabel6 = new JLabel();
			jLabel6.setBounds(new Rectangle(0, 130, 90, 19));
			jLabel6.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel6.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel6.setText("����J�F");
			jLabel5 = new JLabel();
			jLabel5.setBounds(new Rectangle(0, 100, 192, 19));
			jLabel5.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel5.setText("�A�J�E���g�쐬���F");
			jLabel4 = new JLabel();
			jLabel4.setBounds(new Rectangle(82, 80, 110, 19));
			jLabel4.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel4.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel4.setText("���ݒn�F");
			jLabel3 = new JLabel();
			jLabel3.setBounds(new Rectangle(82, 60, 110, 19));
			jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel3.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel3.setText("Web�F");
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(505, 40, 33, 19));
			jLabel2.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel2.setText("ID�F");
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(82, 40, 110, 19));
			jLabel1.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel1.setText("�j�b�N�l�[���F");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(82, 20, 110, 19));
			jLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel.setFont(new Font("Dialog", Font.PLAIN, 14));
			jLabel.setText("���[�U�[���F");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jLabel, null);
			jContentPane.add(jLabel1, null);
			jContentPane.add(jLabel2, null);
			jContentPane.add(jLabel3, null);
			jContentPane.add(jLabel4, null);
			jContentPane.add(jLabel5, null);
			jContentPane.add(jLabel6, null);
			jContentPane.add(jLabel7, null);
			jContentPane.add(jLabel8, null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(jLabel9, null);
			jContentPane.add(jLabel10, null);
			jContentPane.add(jLabel11, null);
			jContentPane.add(jLabel12, null);
			jContentPane.add(jLabel13, null);
			jContentPane.add(getJScrollPane1(), null);
			jContentPane.add(getJButton(), null);
			jContentPane.add(jLabel14, null);
			jContentPane.add(jLabel15, null);
			jContentPane.add(jLabel16, null);
			jContentPane.add(jLabel17, null);
			jContentPane.add(jLabel18, null);
			jContentPane.add(jLabel19, null);
			jContentPane.add(jLabel20, null);
			jContentPane.add(jLabel21, null);
			jContentPane.add(jLabel22, null);
			jContentPane.add(jLabel23, null);
			jContentPane.add(jLabel24, null);
			jContentPane.add(jLabel25, null);
			jContentPane.add(jLabel26, null);
			jContentPane.add(jLabel27, null);
			jContentPane.add(jLabel28, null);
		}
		return jContentPane;
	}

	public static void url_open(String url) {
		String osName = System.getProperty("os.name");

		try {
			if(osName.startsWith("Mac OS")){
				Class<?> fileMgr = null;
				fileMgr = Class.forName("com.apple.eio.FileManager");

				Method openURL = fileMgr.getDeclaredMethod("openURL",new Class[] {String.class});
				openURL.invoke(null, new Object[] {url.trim()});

			}else if(osName.startsWith("Windows")){
				Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url.trim());
			}else{
				String[] browsers = {"firefox", "opera", "konqueror","epiphany", "mozilla", "netscape" };

				String browser = null;

				for (int count = 0; count < browsers.length && browser == null; count++)

					if (Runtime.getRuntime().exec(new String[] {"which", browsers[count]}).waitFor() == 0)
						browser = browsers[count];
                
				if (browser == null) {    
				}else {
					Runtime.getRuntime().exec(new String[] {browser, url.trim()});
				}
			}
		} catch (IOException e) {
			System.out.println(e);
		} catch (SecurityException e) {
			System.out.println(e);
		} catch (NoSuchMethodException e) {
			System.out.println(e);
		} catch (IllegalArgumentException e) {
			System.out.println(e);
		} catch (IllegalAccessException e) {
			System.out.println(e);
		} catch (InvocationTargetException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		
	}

	/**
	 * This method initializes jTextArea	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextArea() {
		if (jTextArea == null) {
			jTextArea = new JTextArea();
			jTextArea.setEditable(false);
			jTextArea.setFont(new Font("Dialog", Font.PLAIN, 12));
			jTextArea.setCursor(new Cursor(Cursor.TEXT_CURSOR));
		}
		return jTextArea;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(90, 150, 530, 90));
			jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			jScrollPane.setAutoscrolls(false);
			jScrollPane.setViewportView(getJTextArea());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jScrollPane1	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setBounds(new Rectangle(90, 330, 530, 90));
			jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			jScrollPane1.setViewportView(getJTextArea1());
		}
		return jScrollPane1;
	}

	/**
	 * This method initializes jTextArea1	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextArea1() {
		if (jTextArea1 == null) {
			jTextArea1 = new JTextArea();
			jTextArea1.setEditable(false);
			jTextArea1.setCursor(new Cursor(Cursor.TEXT_CURSOR));
		}
		return jTextArea1;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(530, 430, 90, 25));
			jButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton.setText("����");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					dispose();
				}
			});
		}
		return jButton;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
