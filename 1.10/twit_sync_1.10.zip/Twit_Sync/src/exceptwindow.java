import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Point;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import java.awt.Rectangle;
import javax.swing.JButton;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;

public class exceptwindow extends JDialog {
	static JDialog exceptwindow;
	private static final long serialVersionUID = 1L;
	private static int count;
	private JPanel jContentPane = null;
	private JScrollPane jScrollPane = null;
	private JTable jTable = null;
	private JScrollPane jScrollPane1 = null;
	private JTable jTable1 = null;
	static String[] columnNames = {"�ԍ�", "ID", "���[�U�[��", "�j�b�N�l�[��"};
	static String[] columnNames2 = {"ID", "���[�U�[��", "�j�b�N�l�[��"};
	public static DefaultTableModel tableModel1 = new DefaultTableModel(columnNames , 0);
	public static DefaultTableModel tableModel2 = new DefaultTableModel(columnNames2 , 0);
	private JButton jButton = null;
	private JButton jButton1 = null;
	private JButton jButton2 = null;
	private JLabel jLabel = null;
	protected int row;
	protected int column;
	public static List<Integer> except_list;  //  @jve:decl-index=0:
	/**
	 * @param owner
	 */
	public exceptwindow(Frame owner) {
		super(owner);
		make_sabun();
		initialize();
		jLabel.setText("���t�H���[���[�U�[�́A" + count + "�l�ł�");
	}

	private void make_sabun() {
		// TODO �����f�[�^���烊�X�g�̍쐬
		List<Integer> follow_sabun;
		count = 0;
		follow_sabun = mainwindow.friends_sabun;
		String follow_data[] = new String[4];
		String user2 = "@" + mainwindow.user2;
		
		for (Integer userid : follow_sabun) {								//�����ɑ΂��ČJ��Ԃ��iuserid�ɂ��̎��̒l�����j
			for(int i=0; i<mainwindow.tableModel1.getRowCount(); ++i){
				if(user2.equals((String) mainwindow.tableModel1.getValueAt(i, 2))){
				}else{
					if(userid.equals(Integer.parseInt((String) mainwindow.tableModel1.getValueAt(i, 1)))) {
						count++;
						follow_data[0] = String.valueOf(count);
						follow_data[1] = String.valueOf(mainwindow.tableModel1.getValueAt(i, 1));
						follow_data[2] = String.valueOf(mainwindow.tableModel1.getValueAt(i, 2));
						follow_data[3] = String.valueOf(mainwindow.tableModel1.getValueAt(i, 3));
						tableModel1.addRow(follow_data);
						System.out.println(follow_data[0] + "," + follow_data[1] + "," + follow_data[2] + "," + follow_data[3]);
						break;
					}
				}
			}
		}
		System.out.println("���t�H���[���[�U�[�F" + count + "�l�ł�");
		System.out.println("--------------------------------------------------------------------------");
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(776, 485);
		this.setModal(true);
		this.setResizable(false);
		this.setTitle("�擾����");
		this.setLocationRelativeTo(null);
		this.setContentPane(getJContentPane());
		this.addWindowListener(new java.awt.event.WindowAdapter(){
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.out.println("x�{�^����������");
				set_except_list();
			}
		});
	}

	private void set_except_list() {
		// TODO Auto-generated method stub
		System.out.println("���O���X�g��ǂݍ��݂܂�");
		except_list = add_except_list();		
	}

	private List<Integer> add_except_list() {
		List<Integer> returnValue = new ArrayList<Integer>();
		for(int i=0; i<tableModel2.getRowCount(); ++i){
			System.out.println(tableModel2.getValueAt(i, 0));
			returnValue.add(Integer.parseInt((String)tableModel2.getValueAt(i, 0)));
		}
		
		return returnValue;
		
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null){
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(10, 380, 399, 16));
			jLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
			jLabel.setText("JLabel");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(getJScrollPane1(), null);
			jContentPane.add(getJButton(), null);
			jContentPane.add(getJButton1(), null);
			jContentPane.add(getJButton2(), null);
			jContentPane.add(jLabel, null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(0, 0, 400, 370));
			jScrollPane.setViewportView(getJTable());
			jScrollPane.getViewport().setBackground(Color.white);
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTable() {
		if (jTable == null) {
			jTable = new JTable(tableModel1);
			jTable.setDefaultEditor(Object.class, null);					//�Z����ҏW�s��
			jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);	//�����ɂQ�̗�̑I����s��
			jTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);				//�J�����̎��������@�\���I�t
			jTable.setShowGrid(false);										//�c���̐���\�������Ȃ�
			jTable.getTableHeader().setReorderingAllowed(false);			//�J�����ړ��s��
			jTable.setAutoCreateRowSorter(true);							//�\�[�g��L����
			jTable.setCellSelectionEnabled(true);
			jTable.setBackground(Color.white);
			jTable.setColumnSelectionAllowed(false);
			
			JMenuItem jmenuitem1 = new JMenuItem();
			jmenuitem1.setText("���O���X�g�ɒǉ�");
			jmenuitem1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					add_except(row);
				}
			});
			JMenuItem jmenuitem2 = new JMenuItem();
			jmenuitem2.setText("�v���t�B�[����\��");
			jmenuitem2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					mainwindow.show_user = Integer.parseInt((String)jTable.getValueAt(jTable.getSelectedRow(), 1));
					System.out.println("���̃��[�U�[�̃v���t�B�[���E�B���h�E��\�����܂� - " + jTable.getValueAt(jTable.getSelectedRow(), 2));
					profilewindow profilewindow = new profilewindow(null);
					profilewindow.setVisible(true);
				}
			});
			JMenuItem jmenuitem3 = new JMenuItem();
			jmenuitem3.setText("�v���t�B�[�����u���E�U�ŕ\��");
			jmenuitem3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("���̃��[�U�[�̃v���t�B�[�����u���E�U�ŊJ���܂� - " + jTable.getValueAt(jTable.getSelectedRow(), 2));
					profilewindow.url_open("http://twitter.com/" + jTable.getValueAt(jTable.getSelectedRow(), 2));
				}
			});
			final JPopupMenu jpopup1 = new JPopupMenu();
			jpopup1.add(jmenuitem1);
			jpopup1.addSeparator();
			jpopup1.add(jmenuitem2);
			jpopup1.add(jmenuitem3);
			this.add(jpopup1);
			
			jTable.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					if(e.getClickCount()==2) {
						Point pt = e.getPoint();
						row = jTable.convertRowIndexToModel(jTable.rowAtPoint(pt));
						add_except(row);
					}else if(SwingUtilities.isRightMouseButton(e)){
						Point point = e.getPoint();
						row = jTable.rowAtPoint(point);
						column = jTable.columnAtPoint(point);
						jTable.changeSelection(row, column, false, false);
						jpopup1.show(jTable, e.getX(), e.getY());
					}
				}
			});
			
			String osName = System.getProperty("os.name");
			
			int column_Windows[] = {45, 60, 110, 166};
			int column_Mac[] = {45, 60, 105, 171};
			int column_Linux[] = {45, 80, 115, 136};
			int column_size[];
			
			if(osName.startsWith("Mac OS")){
				column_size = column_Mac;
			}else if(osName.startsWith("Windows")){
				column_size = column_Windows;
			}else{
				column_size = column_Linux;
			}
			
			for (int i = 0; i < 4; i++){
				TableColumn col = jTable.getColumnModel().getColumn(i);
				col.setPreferredWidth(column_size[i]);
			}
			
		}
		return jTable;
	}

	protected void add_except(int row) {
		String except_data[] = new String[3];
		boolean already_being = false;
		if(tableModel2.getRowCount() == 0){
			except_data[0] = String.valueOf(tableModel1.getValueAt(row, 1));
			except_data[1] = String.valueOf(tableModel1.getValueAt(row, 2));
			except_data[2] = String.valueOf(tableModel1.getValueAt(row, 3));
			tableModel2.addRow(except_data);
			System.out.println("���̃��[�U�[�����O���X�g�ɒǉ����܂����F" + except_data[0] + "," + except_data[1] + "," + except_data[2]);
		}else{
			for(int i=0; i<tableModel2.getRowCount(); ++i){
				if(tableModel1.getValueAt(row, 1).equals((String)tableModel2.getValueAt(i, 0))) {
					already_being = true;
					break;
				}
			}
			if(already_being == false){
				except_data[0] = String.valueOf(tableModel1.getValueAt(row, 1));
				except_data[1] = String.valueOf(tableModel1.getValueAt(row, 2));
				except_data[2] = String.valueOf(tableModel1.getValueAt(row, 3));
				tableModel2.addRow(except_data);
				System.out.println("���̃��[�U�[�����O���X�g�ɒǉ����܂����F" + except_data[0] + "," + except_data[1] + "," + except_data[2]);
			}
		}
	}

	/**
	 * This method initializes jScrollPane1	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setBounds(new Rectangle(410, 0, 360, 370));
			jScrollPane1.setViewportView(getJTable1());
			jScrollPane1.getViewport().setBackground(Color.white);
		}
		return jScrollPane1;
	}

	/**
	 * This method initializes jTable1	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTable1() {
		if (jTable1 == null) {
			jTable1 = new JTable(tableModel2);
			jTable1.setDefaultEditor(Object.class, null);					//�Z����ҏW�s��
			jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);	//�����ɂQ�̗�̑I����s��
			jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);				//�J�����̎��������@�\���I�t
			jTable1.setShowGrid(false);										//�c���̐���\�������Ȃ�
			jTable1.getTableHeader().setReorderingAllowed(false);			//�J�����ړ��s��
			jTable1.setAutoCreateRowSorter(true);							//�\�[�g��L����
			jTable1.setCellSelectionEnabled(true);
			jTable1.setBackground(Color.white);
			jTable1.setColumnSelectionAllowed(false);
			
			JMenuItem jmenuitem1 = new JMenuItem();
			jmenuitem1.setText("���O���X�g����폜");
			jmenuitem1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					tableModel2.removeRow(row);
				}
			});
			JMenuItem jmenuitem2 = new JMenuItem();
			jmenuitem2.setText("�v���t�B�[����\��");
			jmenuitem2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					mainwindow.show_user = Integer.parseInt((String)jTable1.getValueAt(jTable1.getSelectedRow(), 0));
					System.out.println("���̃��[�U�[�̃v���t�B�[���E�B���h�E��\�����܂� - " + jTable1.getValueAt(jTable1.getSelectedRow(), 1));
					profilewindow profilewindow = new profilewindow(null);
					profilewindow.setVisible(true);
				}
			});
			JMenuItem jmenuitem3 = new JMenuItem();
			jmenuitem3.setText("�v���t�B�[�����u���E�U�ŕ\��");
			jmenuitem3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("���̃��[�U�[�̃v���t�B�[�����u���E�U�ŊJ���܂� - " + jTable1.getValueAt(jTable1.getSelectedRow(), 1));
					profilewindow.url_open("http://twitter.com/" + jTable1.getValueAt(jTable1.getSelectedRow(), 1));
				}
			});
			final JPopupMenu jpopup2 = new JPopupMenu();
			jpopup2.add(jmenuitem1);
			jpopup2.addSeparator();
			jpopup2.add(jmenuitem2);
			jpopup2.add(jmenuitem3);
			this.add(jpopup2);
			
			jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					if(e.getClickCount()==2) {
						Point pt = e.getPoint();
						row = jTable1.convertRowIndexToModel(jTable1.rowAtPoint(pt));
						tableModel2.removeRow(row);
					}else if(SwingUtilities.isRightMouseButton(e)){
						Point point = e.getPoint();
						row = jTable1.rowAtPoint(point);
						column = jTable1.columnAtPoint(point);
						jTable1.changeSelection(row, column, false, false);
						jpopup2.show(jTable1, e.getX(), e.getY());
					}
				}
			});
			
			String osName = System.getProperty("os.name");
			
			int column_Windows[] = {60, 110, 166};
			int column_Mac[] = {60, 105, 171};
			int column_Linux[] = {80, 115, 136};
			int column_size[];
			
			if(osName.startsWith("Mac OS")){
				column_size = column_Mac;
			}else if(osName.startsWith("Windows")){
				column_size = column_Windows;
			}else{
				column_size = column_Linux;
			}
			
			for (int i = 0; i < 3; i++){
				TableColumn col = jTable1.getColumnModel().getColumn(i);
				col.setPreferredWidth(column_size[i]);
			}
			
		}
		return jTable1;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(670, 420, 90, 25));
			jButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton.setText("OK");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("OK�{�^�����N���b�N");
					set_except_list();
					dispose();
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if(jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(570, 420, 90, 25));
			jButton1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton1.setText("�J��");
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("�J���{�^�����N���b�N");
					JFileChooser filechooser = new JFileChooser();
					filechooser.setDialogTitle("���O���X�g���J��");
					
					FileFilter filter1 = new FileNameExtensionFilter("Twit Sync Except File (*.tsef)", "tsef");
					filechooser.addChoosableFileFilter(filter1);
					File file = null;
					int selected = filechooser.showOpenDialog(exceptwindow);
					if (selected == JFileChooser.APPROVE_OPTION){
						file = filechooser.getSelectedFile();
						System.out.println("");
					}else if (selected == JFileChooser.CANCEL_OPTION){
						System.out.println("");
						System.out.println("�L�����Z������܂���");
					}else if (selected == JFileChooser.ERROR_OPTION){
						System.out.println("");
						System.out.println("�G���[���͎����������܂���");
					}

					if (file != null){
						tableModel2.setRowCount(0);
						try{
							FileReader in = new FileReader(file);
							BufferedReader br = new BufferedReader(in);
							String line;
							int count = 0;
							String except_user_load_data[] = new String[3];
							while ((line = br.readLine()) != null) {
								count++;
								if(count == 1){
									except_user_load_data[0] = line;
								}else if(count == 2){
									except_user_load_data[1] = line;
								}else if(count == 3){
									except_user_load_data[2] = line;
									count = 0;
									System.out.println(except_user_load_data[0] + "," + except_user_load_data[1] + "," + except_user_load_data[2]);
									tableModel2.addRow(except_user_load_data);
								}
							}
							br.close();
							in.close();
						}catch(IOException e1){
							System.out.println(e1);
						}
					}
					
				}
			});
		}
		return jButton1;
	}
	/**
	 * This method initializes jButton2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton2() {
		if(jButton2 == null){
			jButton2 = new JButton();
			jButton2.setBounds(new Rectangle(470, 420, 90, 25));
			jButton2.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton2.setText("�ۑ�");
			jButton2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("�ۑ��{�^�����N���b�N");
					JFileChooser filechooser = new JFileChooser();
					filechooser.setDialogTitle("���O���X�g��ۑ�");
					
					FileFilter filter1 = new FileNameExtensionFilter("Twit Sync Except File (*.tsef)", "tsef");
					filechooser.addChoosableFileFilter(filter1);
					File file = null;
					int selected = filechooser.showSaveDialog(exceptwindow);
					if (selected == JFileChooser.APPROVE_OPTION){
						file = filechooser.getSelectedFile();
						System.out.println("");
					}else if (selected == JFileChooser.CANCEL_OPTION){
						System.out.println("");
						System.out.println("�L�����Z������܂���");
					}else if (selected == JFileChooser.ERROR_OPTION){
						System.out.println("");
						System.out.println("�G���[���͎����������܂���");
					}
					String except_user_data[] = new String[3];
					
					if (file != null){
						if (!file.exists()){
							try {
								file.createNewFile();
							} catch (IOException e1) {
								System.out.println(e1);
							}	
						}
						try{
							if (checkBeforeWritefile(file)){
								PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));    
								for(int i=0; i<tableModel2.getRowCount(); ++i){
									except_user_data[0] = (String) tableModel2.getValueAt(i, 0);
									except_user_data[1] = (String) tableModel2.getValueAt(i, 1);
									except_user_data[2] = (String) tableModel2.getValueAt(i, 2);
									pw.println(except_user_data[0]);
									pw.println(except_user_data[1]);
									pw.println(except_user_data[2]);
								}
								pw.close();
								System.out.println("���O���X�g��ۑ����܂����F" + file);
							}else{
								System.out.println("�t�@�C���ɏ������߂܂���");
							}
						}catch(IOException e1){
							System.out.println(e1);
						}
					}
				}
			});
		}
		return jButton2;
	}

	private boolean checkBeforeWritefile(File file) {
		//�t�@�C���������ݎ��̏������݉\���`�F�b�N����
		if (file.exists()){
			if (file.isFile() && file.canWrite()){
				return true;
			}
			}
		return false;
	}
	

}  //  @jve:decl-index=0:visual-constraint="10,10"
