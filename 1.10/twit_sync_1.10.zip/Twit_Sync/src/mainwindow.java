import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.SwingWorker;
import javax.swing.UIManager;

import java.awt.event.KeyEvent;
import java.awt.Font;
import javax.swing.JMenuItem;
import javax.swing.JComboBox;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import twitter4j.PagableResponseList;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.TwitterException;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.http.AccessToken;
import javax.swing.JLabel;
import java.awt.Toolkit;
import javax.swing.JPopupMenu;

public class mainwindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JMenuBar jJMenuBar = null;
	private JMenu jMenu = null;
	private JMenu jMenu1 = null;
	private JMenuItem jMenuItem = null;
	private JMenuItem jMenuItem1 = null;
	private static JComboBox jComboBox = null;
	private static JComboBox jComboBox1 = null;
	private static JButton jButton = null;
	private static JButton jButton1 = null;
	private JScrollPane jScrollPane = null;
	static JTable jTable = null;
	private JScrollPane jScrollPane1 = null;
	static JTable jTable1 = null;
	public static DefaultComboBoxModel comboboxmodel;
	public static DefaultComboBoxModel comboboxmodel1;
	
	static String[] columnNames = {"�ԍ�", "ID", "���[�U�[��", "�j�b�N�l�[��"};
	static String user1 = null;  //  @jve:decl-index=0:
	static String user2 = null;
	
	public static DefaultTableModel tableModel1 = new DefaultTableModel(columnNames , 0);
	public static DefaultTableModel tableModel2 = new DefaultTableModel(columnNames , 0);

	private JLabel jLabel = null;
	protected int row;
	protected int column;
	static int show_user;
	private static mainwindow thisClass;
	protected static Object user2_id;
	static boolean set_limit;
	static Twitter twitter;  //  @jve:decl-index=0:
	static TwitterFactory twitterfactory;  //  @jve:decl-index=0:
	static List<Integer> last_friends_sabun;  //  @jve:decl-index=0:
	private static JLabel jLabel1 = null;
	private static JLabel jLabel2 = null;
	static List<Integer> friends_sabun;
	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.add(getJMenu());
			jJMenuBar.add(getJMenu1());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenu() {
		if (jMenu == null) {
			jMenu = new JMenu();
			jMenu.setText("�t�@�C��(F)");
			jMenu.setFont(new Font("Dialog", Font.PLAIN, 12));
			jMenu.setMnemonic(KeyEvent.VK_F);
			jMenu.add(getJMenuItem());
		}
		return jMenu;
	}

	/**
	 * This method initializes jMenu1	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenu1() {
		if (jMenu1 == null) {
			jMenu1 = new JMenu();
			jMenu1.setText("�c�[��(T)");
			jMenu1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jMenu1.setMnemonic(KeyEvent.VK_T);
			jMenu1.add(getJMenuItem1());
		}
		return jMenu1;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem() {
		if (jMenuItem == null) {
			jMenuItem = new JMenuItem();
			jMenuItem.setText("�I��(X)");
			jMenuItem.setFont(new Font("Dialog", Font.PLAIN, 12));
			jMenuItem.setMnemonic(KeyEvent.VK_X);
			jMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.exit(0);
					

				}
			});
		}
		return jMenuItem;
	}

	/**
	 * This method initializes jMenuItem1	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem1() {
		if (jMenuItem1 == null) {
			jMenuItem1 = new JMenuItem();
			jMenuItem1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jMenuItem1.setMnemonic(KeyEvent.VK_A);
			jMenuItem1.setText("�A�J�E���g(A)");
			jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					accountsetting thisClass1 = new accountsetting(null);
					thisClass1.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
					thisClass1.setVisible(true);
				}
			});
		}
		return jMenuItem1;
	}

	/**
	 * This method initializes jComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBox() {
		if (jComboBox == null) {
			jComboBox = new JComboBox(comboboxmodel);
			jComboBox.setBounds(new Rectangle(10, 19, 190, 21));
			jComboBox.setFont(new Font("Dialog", Font.PLAIN, 12));
			jComboBox.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					if((String)comboboxmodel.getSelectedItem() == (String)comboboxmodel1.getSelectedItem()){
						jButton1.setEnabled(false);
					}else{
						jButton1.setEnabled(true);
					}
				}
			});
		}
		return jComboBox;
	}

	/**
	 * This method initializes jComboBox1	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBox1() {
		if (jComboBox1 == null) {
			jComboBox1 = new JComboBox(comboboxmodel1);
			jComboBox1.setBounds(new Rectangle(450, 19, 190, 21));
			jComboBox1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jComboBox1.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					if((String)comboboxmodel1.getSelectedItem() == (String)comboboxmodel.getSelectedItem()){
						jButton1.setEnabled(false);
					}else{
						jButton1.setEnabled(true);
					}
				}
			});
		}
		return jComboBox1;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(770, 440, 80, 25));
			jButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton.setEnabled(false);
			jButton.setText("�J�n");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					do_follow();
				}
			});
		}
		return jButton;
	}

	protected void do_follow() {
		// TODO Auto-generated method stub
		last_friends_sabun = calcNotFollow(exceptwindow.except_list, friends_sabun);
		if(last_friends_sabun.contains(user2_id)){
			last_friends_sabun.remove(user2_id);
		}
		if(last_friends_sabun.size() > 100){
			int value = JOptionPane.showConfirmDialog(null, "���̏����ł�" + last_friends_sabun.size() + "�l�̃��[�U�[���A@" + user2 + "�Ńt�H���[���܂��B\n" +
					"��������̃��[�U�[���t�H���[���邽�߁A�A�J�E���g����������鋰�ꂪ����܂��B\n��x�Ƀt�H���[����l����100�l�ɐ������đ��s���܂����H\n" +
					"�u�͂��v�Ő�������ő��s�A�u�������v�Ő����Ȃ��ő��s�A�u������v�Œ��f���܂��B", 
					"Twit Sync", JOptionPane.YES_NO_CANCEL_OPTION , JOptionPane.WARNING_MESSAGE);
			if (value == JOptionPane.YES_OPTION){
				set_limit = true;
				jButton.setEnabled(false);
				new dofollowingwindow(null);
			}else if(value == JOptionPane.NO_OPTION){
				set_limit = false;
				jButton.setEnabled(false);
				new dofollowingwindow(null);
			}else{
			}
		}else{
			set_limit = false;
			jButton.setEnabled(false);
			new dofollowingwindow(null);
		}
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	public static JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(680, 440, 80, 25));
			jButton1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton1.setEnabled(false);
			jButton1.setText("�擾");
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				@Override public void actionPerformed(java.awt.event.ActionEvent e) {
					jButton1.setEnabled(false);
					jComboBox.setEnabled(false);
					jComboBox1.setEnabled(false);
					new SwingWorker<Object, Object>() {
						@Override public Object doInBackground() {
							thisClass.getGlassPane().setVisible(true);
							get_sabun();
							return "Done";
						}
						@Override public void done() {
							jButton.setEnabled(true);
							thisClass.getGlassPane().setVisible(false);
						}
					}.execute();
				}
			});
		}
		return jButton1;
	}

	protected static void get_sabun() {
		System.out.println("�����擾���J�n���܂�");
		String user_token[] = new String[2];
		user1 = (String)comboboxmodel.getSelectedItem();
		user2 = (String)comboboxmodel1.getSelectedItem();
		System.out.println("���������[�U�[�F" + user1);
		System.out.println("�����惆�[�U�[�F" + user2);
		int index = 0;
		try{
			FileReader in = new FileReader("./user/" + user2 + ".txt");
			BufferedReader br = new BufferedReader(in);
			String line;
			while ((line = br.readLine()) != null) {
				user_token[index] = line;
				index++;
			}
			br.close();
			in.close();
		}catch(IOException e1){
			System.out.println(e1 + "��O���������܂���");
		}
		
		//TODO---------------------------------------------�����擾�J�n---------------------------------------
		twitter = null;

		ConfigurationBuilder confbuilder = new ConfigurationBuilder();
		confbuilder.setIncludeEntitiesEnabled(false);
		
		String CONSUMERKEY ="IvhU4wijj1GqsD1GlqmeXg";
		String CONSUMERSECRET ="lkM2h9ZkU8Llm2Mi2TuSFM9imunajwVt9sF18RE8DI";
		String ACCESSTOKEN = user_token[0];
		String ACCESSSECRET = user_token[1];
		
		confbuilder.setOAuthConsumerKey(CONSUMERKEY);
		confbuilder.setOAuthConsumerSecret(CONSUMERSECRET);

		twitterfactory = new TwitterFactory(confbuilder.build());
		twitter = twitterfactory.getOAuthAuthorizedInstance(new AccessToken(ACCESSTOKEN,ACCESSSECRET));
		
		try {
			user2_id = twitter.showUser(user2).getId();
		} catch (TwitterException e2) {
			e2.printStackTrace();
		}
		
		
		long cursor = -1;
		PagableResponseList<User> users = null;
		int count = 0;
		String follow_ids[] = new String[4];
		List<Integer> user1_friends_ids = new ArrayList<Integer>();
	
		do{
			try {
				users = twitter.getFriendsStatuses(user1,cursor);
				if(users != null){
					for(User user :users){
						count++;
						follow_ids[0] = String.valueOf(count);
						follow_ids[1] = String.valueOf(user.getId());
						follow_ids[2] = "@" + user.getScreenName();
						follow_ids[3] = user.getName();
						tableModel1.addRow(follow_ids);
						user1_friends_ids.add(Integer.valueOf(user.getId()));
					}
				}
			}catch (TwitterException e1) {
				e1.printStackTrace();
				
			}
			cursor = users.getNextCursor();
		}while(cursor !=0);
		
		
		cursor = -1;
		PagableResponseList<User> users1 = null;
		int count2 = 0;
		String follow_ids1[] = new String[4];
		List<Integer> user2_friends_ids = new ArrayList<Integer>();
		
		do{
			try {
				users1 = twitter.getFriendsStatuses(user2,cursor);
				if(users1 != null){
					for(User user :users1){
						count2++;
						follow_ids1[0] = String.valueOf(count2);
						follow_ids1[1] = String.valueOf(user.getId());
						follow_ids1[2] = "@" + user.getScreenName();
						follow_ids1[3] = user.getName();
						tableModel2.addRow(follow_ids1);
						user2_friends_ids.add(Integer.valueOf(user.getId()));

					}
				}
			}catch (TwitterException e1) {
				e1.printStackTrace();
				
			}
			cursor = users1.getNextCursor();
		}while(cursor !=0);
		jLabel1.setText(count + "�l");
		jLabel2.setText(count2 + "�l");
		friends_sabun = calcNotFollow(user2_friends_ids, user1_friends_ids);
		System.out.println("--------------------------------------------------------------------------");
		exceptwindow thisClass2 = new exceptwindow(null);
		thisClass2.setVisible(true);	
		//TODO---------------------------------------------�����擾�I��---------------------------------------
		
	}

	public static List<Integer> calcNotFollow(List<Integer> user1FriendsIds, List<Integer> user2FriendsIds) {
		List<Integer> returnValue = new ArrayList<Integer>();
		for(int id : user2FriendsIds) {	
			if(! contains(user1FriendsIds, id)) {
				returnValue.add(Integer.valueOf(id));
			}
		}
		return returnValue;
	}

	public static boolean contains(List<Integer> user1FriendsIds, int id) {
		for(int frendId : user1FriendsIds) {
			if(frendId == id) {
				return true;
			}
		}
		return false;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(10, 40, 400, 370));
			jScrollPane.getViewport().setBackground(Color.white);
			jScrollPane.setViewportView(getJTable());
		}
		return jScrollPane;
	}
	

	/**
	 * This method initializes jTable	
	 * 	
	 * @return javax.swing.JTable	
	 */

	public JTable getJTable() {
		if (jTable == null) {
			jTable = new JTable(tableModel1);
			jTable.setDefaultEditor(Object.class, null);					//�Z����ҏW�s��
			jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);	//�����ɂQ�̗�̑I����s��
			jTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);				//�J�����̎��������@�\���I�t
			jTable.setShowGrid(false);										//�c���̐���\�������Ȃ�
			jTable.getTableHeader().setReorderingAllowed(false);			//�J�����ړ��s��
			jTable.setAutoCreateRowSorter(true);							//�\�[�g��L����
			jTable.setCellSelectionEnabled(true);
			jTable.setBackground(Color.white);
			jTable.setColumnSelectionAllowed(false);
			
			JMenuItem jmenuitem1 = new JMenuItem();
			jmenuitem1.setText("�v���t�B�[����\��");
			jmenuitem1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					show_user = Integer.parseInt((String)jTable.getValueAt(jTable.getSelectedRow(), 1));
					System.out.println("���̃��[�U�[�̃v���t�B�[���E�B���h�E��\�����܂� - " + jTable.getValueAt(jTable.getSelectedRow(), 2));
					profilewindow profilewindow = new profilewindow(null);
					profilewindow.setVisible(true);
				}
			});
			JMenuItem jmenuitem2 = new JMenuItem();
			jmenuitem2.setText("�v���t�B�[�����u���E�U�ŕ\��");
			jmenuitem2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("���̃��[�U�[�̃v���t�B�[�����u���E�U�ŊJ���܂� - " + jTable.getValueAt(jTable.getSelectedRow(), 2));
					profilewindow.url_open("http://twitter.com/" + jTable.getValueAt(jTable.getSelectedRow(), 2));
				}
			});
			final JPopupMenu jpopup1 = new JPopupMenu();
			jpopup1.add(jmenuitem1);
			jpopup1.add(jmenuitem2);
			this.add(jpopup1);
			
			jTable.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					if (SwingUtilities.isRightMouseButton(e)){
						Point point = e.getPoint();
						row = jTable.rowAtPoint(point);
						column = jTable.columnAtPoint(point);
						jTable.changeSelection(row, column, false, false);
						jpopup1.show(jTable, e.getX(), e.getY());
					}
				}
			});
			
			String osName = System.getProperty("os.name");
			
			int column_Windows[] = {45, 60, 110, 166};
			int column_Mac[] = {45, 60, 105, 171};
			int column_Linux[] = {45, 80, 115, 136};
			int column_size[];
			
			if(osName.startsWith("Mac OS")){
				column_size = column_Mac;
			}else if(osName.startsWith("Windows")){
				column_size = column_Windows;
			}else{
				column_size = column_Linux;
			}
			
			for (int i = 0; i < 4; i++){
				TableColumn col = jTable.getColumnModel().getColumn(i);
				col.setPreferredWidth(column_size[i]);
			}
		}
		return jTable;
	}
	
	/**
	 * This method initializes jScrollPane1	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setBounds(new Rectangle(450, 40, 400, 370));
			jScrollPane1.getViewport().setBackground(Color.white);
			jScrollPane1.setViewportView(getJTable1());
		}
		return jScrollPane1;
	}

	/**
	 * This method initializes jTable1	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTable1() {
		if (jTable1 == null) {
			jTable1 = new JTable(tableModel2);
			jTable1.setDefaultEditor(Object.class, null);					//�Z����ҏW�s��
			jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);	//�����ɂQ�̗�̑I����s��
			jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);				//�J�����̎��������@�\���I�t
			jTable1.setShowGrid(false);										//�c���̐���\�������Ȃ�
			jTable1.getTableHeader().setReorderingAllowed(false);			//�J�����ړ��s��
			jTable1.setAutoCreateRowSorter(true);							//�\�[�g��L����
			jTable1.setCellSelectionEnabled(true);
			jTable1.setBackground(Color.white);
			jTable1.setColumnSelectionAllowed(false);
			
			JMenuItem jmenuitem1 = new JMenuItem();
			jmenuitem1.setText("�v���t�B�[����\��");
			jmenuitem1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					show_user = Integer.parseInt((String)jTable1.getValueAt(jTable1.getSelectedRow(), 1));
					System.out.println("���̃��[�U�[�̃v���t�B�[���E�B���h�E��\�����܂� - " + jTable1.getValueAt(jTable1.getSelectedRow(), 2));
					profilewindow profilewindow = new profilewindow(null);
					profilewindow.setVisible(true);
				}
			});
			JMenuItem jmenuitem2 = new JMenuItem();
			jmenuitem2.setText("�v���t�B�[�����u���E�U�ŕ\��");
			jmenuitem2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("���̃��[�U�[�̃v���t�B�[�����u���E�U�ŊJ���܂� - " + jTable1.getValueAt(jTable1.getSelectedRow(), 2));
					profilewindow.url_open("http://twitter.com/" + jTable1.getValueAt(jTable1.getSelectedRow(), 2));
				}
			});
			final JPopupMenu jpopup2 = new JPopupMenu();
			jpopup2.add(jmenuitem1);
			jpopup2.add(jmenuitem2);
			this.add(jpopup2);
			
			jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					if (SwingUtilities.isRightMouseButton(e)){
						Point point = e.getPoint();
						row = jTable1.rowAtPoint(point);
						column = jTable1.columnAtPoint(point);
						jTable1.changeSelection(row, column, false, false);
						jpopup2.show(jTable1, e.getX(), e.getY());
					}
				}
			});
			
			String osName = System.getProperty("os.name");
			
			int column_Windows[] = {45, 60, 110, 166};
			int column_Mac[] = {45, 60, 105, 171};
			int column_Linux[] = {45, 80, 115, 136};
			int column_size[];
			
			if(osName.startsWith("Mac OS")){
				column_size = column_Mac;
			}else if(osName.startsWith("Windows")){
				column_size = column_Windows;
			}else{
				column_size = column_Linux;
			}
			
			for (int i = 0; i < 4; i++){
				TableColumn col = jTable1.getColumnModel().getColumn(i);
				col.setPreferredWidth(column_size[i]);
			}

		}
		return jTable1;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				//�V�X�e���ŗL��GUI�Ăяo��
				try{
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				}catch(Exception e) {
					e.printStackTrace();
				}
				//�I��
				comboboxmodel = new DefaultComboBoxModel();
				comboboxmodel1 = new DefaultComboBoxModel();
				System.out.println("���[�U�[���X�g��ǂݍ��݂܂�");
				File fl = new File("./user_list.txt");
				if(fl.exists()){
					try{
						System.out.println("���[�U�[���X�g���m�F���܂���");
						FileReader in = new FileReader("./user_list.txt");
						BufferedReader br = new BufferedReader(in);
						String line;
						while ((line = br.readLine()) != null) {
							System.out.println(line);
							comboboxmodel.addElement(line);
							comboboxmodel1.addElement(line);
						}
						br.close();
						in.close();
					}catch(IOException e){
						System.out.println(e + "��O���������܂���");
					}
				}else{
					System.out.println("�t�@�C��������܂���B");
					System.out.println("�V�������[�U�[���X�g���쐬���܂��B");
					try{
						fl.createNewFile();		  
					}catch(IOException f){
						System.out.println(f + "��O���������܂���");
					}	
				}	
				thisClass = new mainwindow();
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
			}
		});
	}

	/**
	 * This is the default constructor
	 */
	public mainwindow() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setJMenuBar(getJJMenuBar());
		this.setResizable(false);
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/follow_sync128.png")));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(new Rectangle(0, 0, 872, 525));
		this.setLocationRelativeTo(null);
		this.setContentPane(getJContentPane());
		this.setTitle("Twit Sync -Twitter�{�C�E�T�u�C�t�H���[�����v���O����-");
		this.setGlassPane(new LockingGlassPane());
		this.getGlassPane().setVisible(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(770, 20, 80, 16));
			jLabel2.setText("");
			jLabel2.setFont(new Font("Dialog", Font.PLAIN, 12));
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(330, 20, 80, 16));
			jLabel1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jLabel1.setText("");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(411, 40, 38, 370));
			jLabel.setFont(new Font("Dialog", Font.PLAIN, 36));
			jLabel.setText("��");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJComboBox(), null);
			jContentPane.add(getJComboBox1(), null);
			jContentPane.add(getJButton(), null);
			jContentPane.add(getJButton1(), null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(getJScrollPane1(), null);
			jContentPane.add(jLabel, null);
			jContentPane.add(jLabel1, null);
			jContentPane.add(jLabel2, null);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="41,11"
