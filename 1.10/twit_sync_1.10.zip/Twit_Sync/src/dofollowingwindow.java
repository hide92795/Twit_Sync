import javax.swing.JPanel;

import java.awt.Cursor;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JProgressBar;

import twitter4j.TwitterException;

import java.awt.Rectangle;
import java.util.List;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.SwingWorker;

import java.awt.Font;

public class dofollowingwindow extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JProgressBar jProgressBar = null;
	static List<Integer> last_friends_sabun;  //  @jve:decl-index=0:
	private JTextArea jTextArea = null;
	private JScrollPane jScrollPane = null;
	private JButton jButton = null;
	private JButton jButton1 = null;
	static boolean follow_control = false;

	/**
	 * @param owner
	 */
	public dofollowingwindow(Frame owner) {
		super(owner);
		initialize();
		
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(525, 260);
		this.setModal(true);
		this.setTitle("�t�H���[������...");
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setContentPane(getJContentPane());
		this.setVisible(true);
	}

	public void dofollow(){
		// TODO �t�H���[�J�n
		showmessage("�t�H���[�������J�n���܂�");
		this.repaint();
		int size;
		if(mainwindow.set_limit == true){
			size = 100;
		}else{
			size = mainwindow.last_friends_sabun.size();
		}
		jProgressBar.setMaximum(size);
		int count = 0;

		finish:
		for (Integer userId : mainwindow.last_friends_sabun) {
			count++;
			if(mainwindow.set_limit == true){
				if(count > 100){
					break finish;
				}
			}
			if(follow_control == true){
				showmessage("�t�H���[�����𒆒f���܂���");
				break finish;
			}
			System.out.println(count + "/" + size + " - " + userId);
			jTextArea.append(count + "/" + size + " - " + userId + "\n");
			try {
				mainwindow.twitter.createFriendship(userId);
				showmessage("�t�H���[���܂����F" + userId);
			}catch (TwitterException e) {
				showmessage("�t�H���[�Ɏ��s���܂����F" + userId);
			}finally{
				System.out.println("");
				jProgressBar.setValue(count);
			}
		}
		jButton1.setEnabled(false);
		showmessage("�t�H���[�������I�����܂���");
	}

	private void showmessage(String mes) {
		System.out.println(mes);
		jTextArea.append(mes + "\n");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJProgressBar(), null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(getJButton(), null);
			jContentPane.add(getJButton1(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jProgressBar	
	 * 	
	 * @return javax.swing.JProgressBar	
	 */
	private JProgressBar getJProgressBar() {
		if (jProgressBar == null) {
			jProgressBar = new JProgressBar();
			jProgressBar.setBounds(new Rectangle(10, 10, 500, 20));
		}
		return jProgressBar;
	}

	/**
	 * This method initializes jTextArea	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextArea() {
		if (jTextArea == null) {
			jTextArea = new JTextArea();
			jTextArea.setEditable(false);
			jTextArea.setCursor(new Cursor(Cursor.TEXT_CURSOR));
		}
		return jTextArea;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(10, 40, 500, 150));
			jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			jScrollPane.setViewportView(getJTextArea());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(309, 200, 90, 25));
			jButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton.setText("�J�n");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				@Override public void actionPerformed(java.awt.event.ActionEvent e) {
					jButton.setEnabled(false);
                    jButton1.setEnabled(true);
					new SwingWorker<Object, Object>() {
						@Override public Object doInBackground() {
	                        dofollow();
	                        return "Done";
	                    }
	                    @Override public void done() {
	                    	jButton.setEnabled(false);
	                        jButton1.setEnabled(false);
						}
						
					}.execute();
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(419, 200, 90, 25));
			jButton1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton1.setEnabled(false);
			jButton1.setText("���~");
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					jButton1.setEnabled(false);
					follow_control = true;
				}
			});
		}
		return jButton1;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
